<?php

/** Template name: Homepage */

get_header(); ?>

<?php the_content(); ?>

<?php get_footer();
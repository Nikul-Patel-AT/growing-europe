<?php

namespace WebpConverterVendor\MattPlugins\DeactivationModal\Exception;

/**
 * .
 */
class UnknownFormOptionKeyException extends \Exception
{
}
